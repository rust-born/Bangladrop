from django.shortcuts import render

def home(request):
    """
    Renders the homepage for the Bangladeshi dropshipping store.
    """
    return render(request, 'core/index.html')
