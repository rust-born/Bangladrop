# BanglaDrop - Dropshipping E-Commerce Platform

A professional e-commerce platform designed for dropshipping businesses in Bangladesh, built with Python and Django.

## 🚀 Features
- **Product Catalog:** Categories, product displays, and pricing in BDT (৳).
- **Supplier Management:** Integrated supplier and wholesale tracking.
- **Admin Dashboard:** Full management interface for store owners.
- **Responsive Interface:** Designed for seamless shopping on mobile and desktop devices.

## 🛠️ Tech Stack
- **Backend:** Python, Django
- **Database:** SQLite
- **Forms & UI:** Django Crispy Forms (Bootstrap 5)
- **Environment Management:** Python-dotenv, tzdata

## 💻 Local Setup & Development

1. **Clone the repository:**
   ```bash
   git clone [https://github.com/your-username/bangladrop.git](https://github.com/your-username/bangladrop.git)
   cd bangladrop
