from django.db import models

class Supplier(models.Model):
    name = models.CharField(max_length=255, help_text="Supplier or wholesale company name")
    contact_person = models.CharField(max_length=255, blank=True, null=True)
    phone = models.CharField(max_length=50, help_text="Supplier phone number in Bangladesh")
    email = models.EmailField(blank=True, null=True)
    address = models.TextField(blank=True, null=True, help_text="Pickup or office address")
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name
